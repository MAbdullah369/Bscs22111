'use client'
import Header from '../components/Header'
import Footer from '../components/Footer'
import ProjectCard from '../components/ProjectCard'
import { useReveal } from '../hooks/useReveal'
import Image from 'next/image'
import { Metadata } from 'next'

const skills = [
  'C++', 'C', 'Python', 'React', 'Next.js', 'Flutter', 'Node.js',
  'Operating Systems', 'Data Structures & Algorithms', 'TensorFlow Lite',
  'Whisper API', 'MongoDB', 'SQL', 'Docker', 'Git', 'REST APIs',
  'TypeScript', 'Linux', 'Tailwind CSS',
]

const featured = [
  {
    title: 'Quran Recitation App (Final Year Project)',
    description: 'Awarded 1st Position in the Computer Science Department at ITU Sparkup Innovation Summit 2026. Built real-time recitation accuracy feedback using OpenAI\'s Whisper model fine-tuned on custom datasets (+25% error detection) and reduced inference latency from 10s to 1s via INT8 quantization & local TensorFlow Lite deployment.',
    link: 'https://github.com/MAbdullah369',
    tags: ['Flutter', 'Whisper API', 'TensorFlow Lite', 'Python', 'Dart'],
    year: '2025 – Present',
    image: '/projects/quran_app.jpg',
  },
  {
    title: 'TravelHub — Travel & Itinerary Platform',
    description: 'Full-featured travel management and exploration platform enabling dynamic itinerary generation, destination discovery, and multi-tier booking coordination. Integrated RESTful backend services with real-time location mapping, route calculation, and caching layers.',
    link: 'https://github.com/MAbdullah369',
    tags: ['Next.js', 'React.js', 'Node.js', 'MongoDB', 'REST APIs', 'Tailwind CSS'],
    year: '2024',
    image: '/projects/travelhub.jpg',
  },
  {
    title: 'Client-Server Communication System',
    description: 'Engineered high-performance client-server architecture in C utilizing low-level UNIX/POSIX sockets and IPC mechanisms. Implemented custom command parsing, multithreaded request-response handling, and robust packet validation simulating core OS protocols.',
    link: 'https://github.com/MAbdullah369',
    tags: ['C', 'Operating Systems', 'Sockets / IPC', 'Systems Programming', 'Linux'],
    year: '2024',
    image: '/projects/client_server.jpg',
  },
]

export default function Home() {
  useReveal()

  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header />

      {/* ── Hero ───────────────────────────────────────────────── */}
      <section className="hero-wrapper">
        {/* Ambient background lighting */}
        <div className="hero-ambient-orb" />

        {/* Decorative big background number */}
        <span
          className="big-num anim-fade"
          style={{
            position: 'absolute',
            right: '2rem',
            top: '3.5rem',
            pointerEvents: 'none',
            userSelect: 'none',
            opacity: 0.35,
          }}
        >
          01
        </span>

        <div className="hero-grid">
          {/* Left Column: Editorial Content */}
          <div>
            {/* Unified Salutation & Live Status */}
            <div className="hero-salutation anim-fade-up">
              <span className="hero-status-dot" />
              <span style={{ color: 'var(--ink)' }}>Hello — I'm</span>
              <span className="hero-salutation-divider">/</span>
              <span className="hero-salutation-status">Available for Software Roles</span>
            </div>

            {/* Main Headline Name */}
            <h1 className="hero-name-title anim-fade-up anim-fade-up-d1">
              Abdullah Zahid
            </h1>

            {/* Designation / Role Subtitle */}
            <div className="hero-role-badge anim-fade-up anim-fade-up-d1">
              <span className="accent-line" style={{ width: '2.25rem', marginBottom: 0 }} />
              <span style={{ fontSize: '0.85rem', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--accent)' }}>
                Software Developer &amp; Engineer
              </span>
            </div>

            {/* Subtitle / Intro copy */}
            <p
              className="anim-fade-up anim-fade-up-d2"
              style={{
                fontSize: 'clamp(1rem, 1.8vw, 1.15rem)',
                color: 'var(--ink-soft)',
                maxWidth: '46ch',
                lineHeight: 1.75,
                marginBottom: '1.75rem',
              }}
            >
              I build intelligent software systems and high-performance applications — spanning low-level systems programming, embedded AI/ML models, and robust full-stack architectures.
            </p>

            {/* Key Focus Tag Chips */}
            <div className="hero-chips-grid anim-fade-up anim-fade-up-d2">
              <span className="hero-chip">
                <span style={{ color: 'var(--accent)' }}>✦</span> AI &amp; Whisper ML Optimization
              </span>
              <span className="hero-chip">
                <span style={{ color: 'var(--accent2)' }}>✦</span> Systems &amp; Low-Level (C / C++)
              </span>
              <span className="hero-chip">
                <span style={{ color: 'var(--gold)' }}>✦</span> Scalable Full-Stack Software
              </span>
            </div>

            {/* Call to Actions */}
            <div
              className="anim-fade-up anim-fade-up-d3"
              style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}
            >
              <a href="/projects" className="btn-primary" style={{ padding: '0.85rem 2rem' }}>
                View Projects →
              </a>
              <a
                href="/contact"
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  padding: '0.8rem 1.85rem',
                  border: '1px solid var(--line)',
                  borderRadius: '2px',
                  fontSize: '0.875rem',
                  fontWeight: 600,
                  letterSpacing: '0.06em',
                  textTransform: 'uppercase',
                  color: 'var(--ink)',
                  background: 'rgba(26, 26, 46, 0.5)',
                  backdropFilter: 'blur(6px)',
                  transition: 'border-color 0.2s, background 0.2s, color 0.2s',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = 'var(--ink)'
                  e.currentTarget.style.background = 'var(--ink)'
                  e.currentTarget.style.color = '#0f0f1e'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'var(--line)'
                  e.currentTarget.style.background = 'rgba(26, 26, 46, 0.5)'
                  e.currentTarget.style.color = 'var(--ink)'
                }}
              >
                Get in touch
              </a>
            </div>
          </div>

          {/* Right Column: Seamlessly Blended Engineering Console */}
          <div className="anim-fade anim-fade-d2">
            <div className="hero-console-card" data-cursor="view" data-cursor-text="DEV PROFILE">
              {/* Terminal Top Bar */}
              <div className="hero-console-header">
                <div className="hero-traffic-dots">
                  <span className="hero-traffic-dot red" />
                  <span className="hero-traffic-dot yellow" />
                  <span className="hero-traffic-dot green" />
                </div>
                
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Image
                    src="/profile.jpg"
                    alt="Abdullah Zahid"
                    width={20}
                    height={20}
                    style={{ borderRadius: '50%', objectFit: 'cover' }}
                  />
                  <span
                    style={{
                      fontSize: '0.74rem',
                      color: 'var(--ink-soft)',
                      fontFamily: 'monospace',
                      letterSpacing: '0.04em',
                    }}
                  >
                    abdullah.config.ts
                  </span>
                </div>

                <span style={{ fontSize: '0.68rem', color: 'var(--accent)', fontWeight: 600, letterSpacing: '0.05em' }}>
                  ACTIVE
                </span>
              </div>

              {/* Code Snippet */}
              <div className="hero-console-body">
                <p><span className="token-kw">const</span> <span className="token-fn">softwareEngineer</span> = &#123;</p>
                <p style={{ paddingLeft: '1.25rem' }}>
                  <span className="token-key">name:</span> <span className="token-str">'Abdullah Zahid'</span>,
                </p>
                <p style={{ paddingLeft: '1.25rem' }}>
                  <span className="token-key">role:</span> <span className="token-str">'Software Developer &amp; Engineer'</span>,
                </p>
                <p style={{ paddingLeft: '1.25rem' }}>
                  <span className="token-key">education:</span> <span className="token-str">'BS CS @ ITU (2022–2026)'</span>,
                </p>
                <p style={{ paddingLeft: '1.25rem' }}>
                  <span className="token-key">languages:</span> [
                </p>
                <p style={{ paddingLeft: '2.25rem' }}>
                  <span className="token-str">'C++'</span>, <span className="token-str">'C'</span>, <span className="token-str">'Python'</span>, <span className="token-str">'TypeScript'</span>, <span className="token-str">'SQL'</span>
                </p>
                <p style={{ paddingLeft: '1.25rem' }}>],</p>
                <p style={{ paddingLeft: '1.25rem' }}>
                  <span className="token-key">specialties:</span> [
                </p>
                <p style={{ paddingLeft: '2.25rem' }}>
                  <span className="token-str">'AI &amp; ML (Whisper / TFLite)'</span>,
                </p>
                <p style={{ paddingLeft: '2.25rem' }}>
                  <span className="token-str">'Systems &amp; IPC / Sockets'</span>,
                </p>
                <p style={{ paddingLeft: '2.25rem' }}>
                  <span className="token-str">'Scalable Full-Stack Architecture'</span>
                </p>
                <p style={{ paddingLeft: '1.25rem' }}>],</p>
                <p style={{ paddingLeft: '1.25rem' }}>
                  <span className="token-key">openToWork:</span> <span className="token-kw">true</span>
                </p>
                <p>&#125;;</p>
              </div>

              {/* Console Footer */}
              <div className="hero-console-footer">
                <span>✦ ITU Sparkup Innovation Award Winner</span>
                <span style={{ color: 'var(--accent)' }}>8+ Projects Shipped ↗</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Skills Ticker ──────────────────────────────────────── */}
      <div
        style={{
          borderTop: '1px solid var(--line)',
          borderBottom: '1px solid var(--line)',
          padding: '0.9rem 0',
          overflow: 'hidden',
          background: 'var(--surface2)',
        }}
      >
        {/* 
          ANIMATION: Marquee / infinite scroll ticker
          - .marquee-track duplicates the list so the scroll looks seamless
          - CSS animation: marquee moves translateX from 0 to -50% (half = one full copy)
          - Pauses on hover via animation-play-state: paused
        */}
        <div className="marquee-track" aria-hidden>
          {[...skills, ...skills].map((s, i) => (
            <span
              key={i}
              style={{
                padding: '0 2rem',
                fontSize: '0.78rem',
                fontWeight: 600,
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
                color: 'var(--muted)',
                whiteSpace: 'nowrap',
              }}
            >
              {s}
              <span style={{ marginLeft: '2rem', color: 'var(--gold)' }}>·</span>
            </span>
          ))}
        </div>
      </div>

      {/* ── Featured Projects ──────────────────────────────────── */}
      <section
        style={{
          maxWidth: '72rem',
          margin: '0 auto',
          padding: 'clamp(4rem, 10vw, 7rem) 1.5rem',
          width: '100%',
        }}
      >
        <div
          className="reveal"
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'baseline',
            marginBottom: '2.5rem',
            gap: '1rem',
          }}
        >
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(1.6rem, 4vw, 2.5rem)',
              letterSpacing: '-0.025em',
            }}
          >
            Featured Work
          </h2>
          <a
            href="/projects"
            style={{
              fontSize: '0.8rem',
              fontWeight: 600,
              letterSpacing: '0.07em',
              textTransform: 'uppercase',
              color: 'var(--accent)',
              whiteSpace: 'nowrap',
            }}
          >
            All projects →
          </a>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(min(100%, 340px), 1fr))',
            gap: '1.25rem',
          }}
        >
          {featured.map((p, i) => (
            <ProjectCard key={p.title} {...p} index={i} />
          ))}
        </div>
      </section>

      {/* ── CTA Band ──────────────────────────────────────────── */}
      <section
        className="reveal"
        style={{
          background: 'linear-gradient(135deg, rgba(255,107,53,0.12) 0%, rgba(79,156,255,0.12) 100%)',
          borderTop: '1px solid var(--line)',
          borderBottom: '1px solid var(--line)',
          padding: 'clamp(3rem, 8vw, 5rem) 1.5rem',
          textAlign: 'center',
        }}
      >
        <p
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(1.4rem, 4vw, 2.4rem)',
            letterSpacing: '-0.02em',
            marginBottom: '1.5rem',
            maxWidth: '20ch',
            margin: '0 auto 1.5rem',
            color: 'var(--ink)',
          }}
        >
          Have a project in mind?
        </p>
        <a
          href="/contact"
          className="btn-primary"
          style={{ background: 'var(--accent)', display: 'inline-flex' }}
        >
          Let's work together →
        </a>
      </section>

      <Footer />
    </main>
  )
}

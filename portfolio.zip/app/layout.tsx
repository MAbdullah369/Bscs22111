import '../styles/globals.css'
import { Metadata } from 'next'
import CustomCursor from '../components/CustomCursor'

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://abdullah-zahid.netlify.app'

export const metadata: Metadata = {
  metadataBase: new URL(BASE_URL),
  title: {
    default: 'Abdullah Zahid — Software Developer',
    template: '%s | Abdullah Zahid',
  },
  description:
    'Portfolio of Abdullah Zahid — Software Developer specializing in AI/ML systems, systems programming, and scalable full-stack applications.',
  keywords: [
    'software developer',
    'software engineer',
    'C++',
    'C',
    'Python',
    'React',
    'Next.js',
    'TensorFlow Lite',
    'Whisper AI',
    'Operating Systems',
    'Data Structures',
    'full-stack developer',
  ],
  authors: [{ name: 'Abdullah Zahid', url: BASE_URL }],
  creator: 'Abdullah Zahid',

  /* ── Open Graph ── */
  openGraph: {
    title: 'Abdullah Zahid — Software Developer',
    description:
      'Portfolio of Abdullah Zahid — Software Developer specializing in AI/ML systems, systems programming, and scalable full-stack software.',
    url: BASE_URL,
    siteName: 'Abdullah Zahid',
    locale: 'en_US',
    type: 'website',
    images: [
      {
        url: `${BASE_URL}/og-image.png`,
        width: 1200,
        height: 630,
        alt: 'Abdullah Zahid — Software Developer',
      },
    ],
  },

  /* ── Twitter / X Card ── */
  twitter: {
    card: 'summary_large_image',
    title: 'Abdullah Zahid — Software Developer',
    description:
      'Portfolio of Abdullah Zahid — Software Developer specializing in AI/ML systems, systems programming, and scalable full-stack software.',
    creator: '@MAbdullah369',
    images: [`${BASE_URL}/og-image.png`],
  },

  /* ── Robots ── */
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },

  /* ── Icons ── */
  icons: {
    icon: [
      { url: '/favicon.svg', type: 'image/svg+xml' },
      { url: '/favicon-32.png', sizes: '32x32', type: 'image/png' },
    ],
    apple: '/apple-touch-icon.png',
  },

  /* ── Verification (add your own tokens) ── */
  verification: {
    google: 'YOUR_GOOGLE_SITE_VERIFICATION_TOKEN',
  },

  /* ── Alternate ── */
  alternates: {
    canonical: BASE_URL,
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        {/* JSON-LD structured data — Person schema */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'Person',
              name: 'Abdullah Zahid',
              url: BASE_URL,
              sameAs: [
                'https://github.com/MAbdullah369',
                'https://linkedin.com/in/mabdullah79',
              ],
              jobTitle: 'Software Developer & Engineer',
              description:
                'Software Developer specializing in AI/ML systems, systems programming, and scalable full-stack applications.',
            }),
          }}
        />
      </head>
      <body>
        <CustomCursor />
        {children}
      </body>
    </html>
  )
}

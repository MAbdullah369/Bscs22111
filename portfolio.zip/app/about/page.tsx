'use client'
import { Metadata } from 'next'
import Image from 'next/image'
import Header from '../../components/Header'
import Footer from '../../components/Footer'
import { useReveal } from '../../hooks/useReveal'

const education = [
  { degree: 'Bachelor of Science in Computer Science', school: 'Information Technology University', period: 'Sept 2022 – June 2026', details: 'Data Structures, Algorithms, AI, Database Management' },
  { degree: 'Intermediate in Pre-Engineering', school: 'Punjab Group of Colleges', period: 'Oct 2020 – June 2022', details: 'Engineering Foundation' },
]

const coursework = [
  'Data Structures',
  'Algorithms Analysis',
  'Operating Systems',
  'Database Management',
  'Artificial Intelligence',
  'Compiler Construction',
]

const skillsSummary = {
  languages: ['C++', 'C', 'Python', 'JavaScript', 'TypeScript', 'SQL', 'HTML/CSS'],
  frameworks: ['React.js', 'Next.js', 'Flutter', 'Node.js', 'Express.js', 'Tailwind CSS', 'TensorFlow Lite', 'Whisper API'],
  tools: ['Linux', 'Git', 'Docker', 'GitHub', 'VS Code', 'Visual Studio'],
}

export default function AboutPage() {
  useReveal()

  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header />

      <section
        style={{
          paddingTop: 'clamp(7rem, 18vw, 10rem)',
          paddingBottom: 'clamp(4rem, 10vw, 7rem)',
          maxWidth: '72rem',
          margin: '0 auto',
          padding: 'clamp(7rem, 18vw, 10rem) 1.5rem clamp(4rem, 10vw, 7rem)',
          width: '100%',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 320px), 1fr))',
          gap: '4rem',
          alignItems: 'start',
        }}
      >
        {/* Left column */}
        <div>
          {/* Avatar with profile picture */}
          <div
            className="anim-fade"
            style={{
              position: 'relative',
              width: '96px', height: '96px',
              marginBottom: '2rem',
            }}
          >
            <div className="pulse-ring" />
            <div className="pulse-ring" />
            <Image
              src="/profile.jpg"
              alt="Abdullah Zahid"
              width={96}
              height={96}
              style={{
                borderRadius: '50%',
                objectFit: 'cover',
                display: 'block',
              }}
              priority
            />
          </div>

          <h1
            className="anim-fade-up"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(2.2rem, 6vw, 3.5rem)',
              letterSpacing: '-0.03em',
              marginBottom: '0.5rem',
            }}
          >
            About Me
          </h1>
          <span className="accent-line" style={{ width: '2.5rem', marginBottom: '1.5rem' }} />

          <p
            className="anim-fade-up anim-fade-up-d1"
            style={{
              color: 'var(--ink-soft)',
              lineHeight: 1.75,
              marginBottom: '1rem',
              fontSize: '1rem',
            }}
          >
            I'm a computer science student at Information Technology University with a strong foundation in software engineering, systems programming, and applied artificial intelligence. I build high-performance software across C/C++, Python, and full-stack ecosystems.
          </p>
          <p
            className="anim-fade-up anim-fade-up-d2"
            style={{ color: 'var(--ink-soft)', lineHeight: 1.75, fontSize: '1rem', marginBottom: '1.5rem' }}
          >
            My final year project — an AI-powered Quranic recitation accuracy analyzer — won 1st Position at the ITU Sparkup Innovation Summit 2026. I am driven by engineering reliable systems, optimizing latency, and solving complex computational challenges.
          </p>

          <div className="anim-fade-up anim-fade-up-d3" style={{ marginTop: '2rem' }}>
            <a href="/contact" className="btn-primary">
              Get in touch →
            </a>
          </div>
        </div>

        {/* Right column — experience & coursework */}
        <div>
          <h2
            className="reveal"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: '1.2rem',
              letterSpacing: '-0.01em',
              marginBottom: '1.25rem',
              color: 'var(--muted)',
            }}
          >
            Education
          </h2>

          <ol style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0', marginBottom: '2.5rem' }}>
            {education.map(({ degree, school, period, details }, i) => (
              <li
                key={i}
                className="reveal"
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr auto',
                  gap: '0.5rem 2rem',
                  alignItems: 'start',
                  padding: '1.25rem 0',
                  borderBottom: '1px solid var(--line)',
                }}
              >
                <div>
                  <p style={{ fontWeight: 600, color: 'var(--ink)', marginBottom: '0.15rem' }}>
                    {degree}
                  </p>
                  <p style={{ fontSize: '0.85rem', color: 'var(--muted)' }}>{school}</p>
                  <p style={{ fontSize: '0.75rem', color: 'var(--muted)', marginTop: '0.35rem' }}>{details}</p>
                </div>
                <span className="tag" style={{ marginTop: '0.1rem', whiteSpace: 'nowrap' }}>
                  {period}
                </span>
              </li>
            ))}
          </ol>

          <h2
            className="reveal"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: '1.2rem',
              letterSpacing: '-0.01em',
              marginBottom: '1rem',
              color: 'var(--muted)',
            }}
          >
            Relevant Coursework
          </h2>

          <div className="reveal" style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '2.5rem' }}>
            {coursework.map((course) => (
              <span key={course} className="tag" style={{ color: 'var(--ink-soft)', borderColor: 'rgba(255,255,255,0.15)' }}>
                ✦ {course}
              </span>
            ))}
          </div>

          <h2
            className="reveal"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: '1.2rem',
              letterSpacing: '-0.01em',
              marginBottom: '1rem',
              color: 'var(--muted)',
            }}
          >
            Technical Stack
          </h2>

          <div className="reveal" style={{ display: 'grid', gap: '0.85rem' }}>
            <div>
              <p style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', color: 'var(--accent)', letterSpacing: '0.08em', marginBottom: '0.35rem' }}>
                Languages
              </p>
              <p style={{ fontSize: '0.85rem', color: 'var(--ink-soft)' }}>
                {skillsSummary.languages.join(' · ')}
              </p>
            </div>
            <div>
              <p style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', color: 'var(--accent2)', letterSpacing: '0.08em', marginBottom: '0.35rem' }}>
                Frameworks &amp; AI
              </p>
              <p style={{ fontSize: '0.85rem', color: 'var(--ink-soft)' }}>
                {skillsSummary.frameworks.join(' · ')}
              </p>
            </div>
            <div>
              <p style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', color: 'var(--gold)', letterSpacing: '0.08em', marginBottom: '0.35rem' }}>
                Tools &amp; Environments
              </p>
              <p style={{ fontSize: '0.85rem', color: 'var(--ink-soft)' }}>
                {skillsSummary.tools.join(' · ')}
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

import Image from 'next/image'

type Props = {
  title: string
  description: string
  link?: string
  tags?: string[]
  year?: string
  index?: number
  image?: string
}

export default function ProjectCard({ title, description, link, tags = [], year, index = 0, image }: Props) {
  return (
    <article
      className="project-card reveal"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      {/* Optional Project Screenshot Preview */}
      {image && (
        <div
          style={{
            position: 'relative',
            width: '100%',
            height: '190px',
            marginBottom: '1.25rem',
            borderRadius: '4px',
            overflow: 'hidden',
            border: '1px solid rgba(255,255,255,0.08)',
            background: 'var(--surface)',
          }}
        >
          <Image
            src={image}
            alt={title}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            style={{
              objectFit: 'cover',
              transition: 'transform 0.5s var(--ease-out-expo)',
            }}
            className="project-image-hover"
          />
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(to top, rgba(15,15,30,0.85) 0%, transparent 50%)',
              pointerEvents: 'none',
            }}
          />
        </div>
      )}

      {/* Top row */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'flex-start',
          marginBottom: '0.85rem',
        }}
      >
        {/* Decorative index number */}
        <span
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: '0.7rem',
            color: 'var(--muted)',
            letterSpacing: '0.1em',
          }}
        >
          {String(index + 1).padStart(2, '0')}
        </span>
        {year && (
          <span className="tag">{year}</span>
        )}
      </div>

      <h3
        style={{
          fontFamily: 'var(--font-display)',
          fontSize: '1.3rem',
          marginBottom: '0.65rem',
          color: 'var(--ink)',
          letterSpacing: '-0.02em',
        }}
      >
        {title}
      </h3>

      <p
        style={{
          fontSize: '0.9rem',
          color: 'var(--ink-soft)',
          lineHeight: '1.65',
          marginBottom: '1.25rem',
        }}
      >
        {description}
      </p>

      {/* Tags */}
      {tags.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem', marginBottom: '1.25rem' }}>
          {tags.map((t) => (
            <span key={t} className="tag">{t}</span>
          ))}
        </div>
      )}

      {/* CTA */}
      {link && (
        <a
          href={link}
          target="_blank"
          rel="noreferrer"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.4rem',
            fontSize: '0.78rem',
            fontWeight: 600,
            letterSpacing: '0.07em',
            textTransform: 'uppercase',
            color: 'var(--accent)',
            transition: 'gap 0.2s',
          }}
          onMouseEnter={(e) => (e.currentTarget.style.gap = '0.7rem')}
          onMouseLeave={(e) => (e.currentTarget.style.gap = '0.4rem')}
        >
          View project
          <span style={{ fontSize: '1rem', lineHeight: 1 }}>→</span>
        </a>
      )}
    </article>
  )
}
